# Answer pipeline (private Phase 6 preview)

Requirement KE-AI-PORT-001: preserve the existing preparation, evidence nomination,
search batch limits, six model turn budget, reserved composition, exact occurrence
history, reference validation and cancellation in one reusable loop. Model
connectors propose tools across resumable turns; the pipeline alone executes them.
The website uses the same source. Host applications own routing, engine analysis,
opening lookup, accounts, transport, persistence and credentials.

`runAnswerPipeline` performs the existing preparation and investigation/composition;
`runPreparedAnswer` accepts already captured evidence. `createNativeAnswerConnector`
adapts an AI SDK LanguageModel; a custom `AnswerModelConnector` invokes any model
turn interface, including a local mock. Delegated agent execution is a different
product contract, not a interchangeable connector. No provider comparison or paid
answer-quality equivalence is claimed.

Connectors return assistant continuation messages with their proposed tool calls.
Preserve opaque provider continuation metadata in memory. Do not execute proposed
tools in connectors: the pipeline performs validation, dispatch and result append.
Cancellation is checked before invocation, after response and around each tool.
`simpleSystemPolicy` and `simpleToolDescription` expose the existing base policy
builder. Hosts must deliberately supply their chosen policy; this base builder
is not a claim of equivalence to the website's currently selected conversational
policy. Website relay adapters continue injecting the existing server-owned prompt.

Preferred public analyzer lines and conditional segments use `mateInMoves`: signed
mate distance in moves. Explicit `toPositionAnalysis` / `toLegacyPositionAnalysis`
adapters retain legacy provider compatibility and reject contradictory aliases.
Existing versioned trace/evidence outputs keep their historical `matePly` spelling;
this is not a trace-schema migration. See the publication contract documentation.

All observations and diagnostic events may contain user chess data. Hosts choose
storage and retention. Published package files contain no recorded study fixtures,
credentials or private traces. Network and engine work requires an injected port.

Budget behavior is inherited: at most six normal model turns, at most eight
searches per batch, reserved final composition, plus the existing one-slot
recovery rules. There is no new aggregate engine-search quota. Connector output
limits may be requested rather than guaranteed. `usage.outputTokens` retains
legacy budget accounting; check `reportedOutputTokens` and `metering` before
reporting measured usage. Missing usage reserves the call allowance and has an
explicit `outputBudgetReservation`; it is not measured usage or billing.

Build independently with `npm install` and `npm run build` in the unpacked
package. `src` is generated from canonical repository modules for packaging,
never a second editable implementation. `npm test` runs the deterministic
connector conformance checks against genuine chess legality/evidence tools.
The deterministic analyzer is a test double and does not qualify engine strength,
provider transport, live answer quality or correctness of generated prose.

Connector capability metadata declares `toolRequests`, `toolFreeComposition`,
`opaqueContinuation` booleans; `outputTokenLimit` is `enforced`, `requested` or
`unavailable`; `usageReporting` is `reported`, `optional` or `unavailable`.
The interface rejects an entire proposed batch before dispatch if a call ID is
empty or repeated, a tool is unknown, arguments are not objects, or the batch
exceeds 32 calls. This is an interface admission ceiling, separate from the
inherited eight-search batch limit. Detailed chess schema and legality checks
remain in the canonical tool wrappers and host.
